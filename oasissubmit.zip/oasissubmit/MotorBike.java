public class MotorBike extends Vehicle {
    private boolean hasSideCar;

    /**
     * constructor.
     */
    public MotorBike(String brand, String model, String registrationNumber, Person owner, boolean hasSideCar) {
        super(brand, model, registrationNumber, owner);
        this.hasSideCar = hasSideCar;
    }

    /**
     * get info.
     */
    @Override
    public String getInfo() {
        String s = "Motor Bike: ";
        s += "\n\tBrand: " + this.brand;
        s += "\n\tModel: " + this.model;
        s += "\n\tRegistration Number: " + this.registrationNumber;
        s += "\n\tHas Side Car: " + this.hasSideCar;
        s += "\n\tBelongs to " + this.owner.getName() + " - " + this.owner.getAddress();
        return s;
    }

    /**
     * is having sidecar.
     */
    public boolean isHasSideCar() {
        return hasSideCar;
    }

    /**
     * set has sidecar.
     */
    public void setHasSideCar(boolean hasSideCar) {
        this.hasSideCar = hasSideCar;
    }
}
