import java.util.ArrayList;
import java.util.List;

public class Person {
    private String name;
    private String address;
    private List<Vehicle> vehicleList;

    /**
     * constructor.
     */
    public Person(String name, String address) {
        this.name = name;
        this.address = address;
        vehicleList = new ArrayList<>();
    }

    /**
     * add vehicle.
     */
    public void addVehicle(Vehicle vehicle) {
        vehicleList.add(vehicle);
    }

    /**
     * remove vehicle.
     */
    public void removeVehicle(String registrationNumber) {
        vehicleList.removeIf(vehicle -> vehicle.getRegistrationNumber().equals(registrationNumber));
    }

    /**
     * get vehiclesInfo.
     */
    public String getVehiclesInfo() {
        if (vehicleList.isEmpty()) {
            return this.name + " has no vehicle!";
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.name + " has:\n\n");
        for (Vehicle vehicle : vehicleList) {
            stringBuilder.append(vehicle.getInfo() + "\n");
        }
        return stringBuilder.toString();
    }

    /**
     * get name.
     */
    public String getName() {
        return name;
    }

    /**
     * set name.
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * get address.
     */
    public String getAddress() {
        return address;
    }

    /**
     * set address.
     */
    public void setAddress(String address) {
        this.address = address;
    }
}
