public class Car extends Vehicle {
    private int numberOfDoors;

    /**
     * constructor.
     */
    public Car(String brand, String model, String registrationNUmber, Person owner, int numberOfDoors) {
        super(brand, model, registrationNUmber, owner);
        this.numberOfDoors = numberOfDoors;
    }

    /**
     * get info.
     */
    @Override
    public String getInfo() {
        String s = "Car: ";
        s += "\n\tBrand: " + this.brand;
        s += "\n\tModel: " + this.model;
        s += "\n\tRegistration Number: " + this.registrationNumber;
        s += "\n\tNumber of Doors: " + this.numberOfDoors;
        s += "\n\tBelongs to " + this.owner.getName() + " - " + this.owner.getAddress();
        return s;
    }

    /**
     * get number of doors.
     */
    public int getNumberOfDoors() {
        return numberOfDoors;
    }

    /**
     * set number of doors.
     */
    public void setNumberOfDoors(int numberOfDoors) {
        this.numberOfDoors = numberOfDoors;
    }
}
